# Barao---1A---Pensamento-ComputacionaProjeto de um site em HDML e CSS
## Site em HTML e CSS

### Colégio Estadual Barão do Rio Branco 
Disciplina de Pensamento Computacional

---

Desenvolvimento de site nas Linguagens HTML e CSS

Estudante: Mariana Amarilla Scarabelot   nº17


Estudante: Maria Clara Ferreira Pontes   n°30
